<center><h2>Selamat Datang di Halaman Utama <br><br> Aplikasi Sistem Pakar Diagnosa Penyakit Umum Pada Balita</h2></center>
<div class="row">
          <div class="col-lg-12">
            <h3><small>Website admin sistem pakar ini bertujuan untuk mengelola data-data penyakit umum pada balita</small></h3>
            </div>
        </div>
